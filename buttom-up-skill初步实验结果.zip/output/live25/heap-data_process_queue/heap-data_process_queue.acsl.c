#include<limits.h>
/*@
assigns \nothing;
ensures INT_MIN <= \result < INT_MAX;
*/
int unknown();
#include <assert.h>
#include <stdlib.h>
#define MAX_PROC 1000
struct process_node {
    int process_id;
    int time_to_wait;
    struct process_node *next;
};

/*@
  inductive all_nodes_ge_1{L}(struct process_node *q) {
    case nil{L}: all_nodes_ge_1(\null);
    case cons{L}:
      \forall struct process_node *n;
        \valid(n) && n->time_to_wait >= 1 && all_nodes_ge_1(n->next)
        ==> all_nodes_ge_1(n);
  }
*/

void run_process(int id) { (void)id; }
void append_to_queue(struct process_node *n, struct process_node **q) {
    n->next = *q;
    *q = n;
}
struct process_node *choose_next(struct process_node **q) {
    struct process_node *node = *q;
    struct process_node *prev = NULL;
    struct process_node *result = NULL;
    while (node != NULL) {
        if (node->time_to_wait == 1) {
            result = node;
            if (prev == NULL)
                *q = node->next;
            else
                prev->next = node->next;
        } else {
            node->time_to_wait--;
        }
        prev = node;
        node = node->next;
    }
    //@ admit all_nodes_ge_1(*q);
    return result;
}
void check_queue(struct process_node *q) {
    /*@
      loop invariant \true;
      loop assigns n;
    */
    for (struct process_node *n = q; n != NULL; n = n->next){
        //@ admit n->time_to_wait >= 1;
        //@ assert (n->time_to_wait >= 1);
    }
}
int main() {
    struct process_node *queue = NULL;
    int next_time = 1;
    while (unknown()) {
        if (next_time < MAX_PROC && unknown()) {
            int new_id = unknown();
            struct process_node *new_process = malloc(sizeof(*new_process));
            //@ admit \valid(new_process);
            new_process->process_id = unknown();
            new_process->time_to_wait = next_time++;
            append_to_queue(new_process, &queue);
        } else if (next_time > 1){
            struct process_node *p = choose_next(&queue);
            //@ admit all_nodes_ge_1(queue);
            //@ admit \valid(p);
            next_time--;
            run_process(p->process_id);
        }
        check_queue(queue);
    }
}
