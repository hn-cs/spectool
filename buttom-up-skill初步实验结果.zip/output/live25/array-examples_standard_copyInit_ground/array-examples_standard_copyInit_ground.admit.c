#include <assert.h>
#define N 100000
int main ( ) {
  int a [N];
  int b [N];
  //@ admit \separated(a+(0 .. N-1), b+(0 .. N-1));
  int i = 0;
  while ( i < N ) {
    a[i] = 42;
    i = i + 1;
  }
  for ( i = 0 ; i < N ; i++ ) {
    b[i] = a[i];
  }
  int x;
  for ( x = 0 ; x < N ; x++ ) {
    //@ assert(b[x] == 42  );
  }
  return 0;
}
