#include<limits.h>
/*@
assigns \nothing;
ensures INT_MIN <= \result <= INT_MAX/4;
*/
int unknown();
#include<stdlib.h>
/*@ requires cond != 0; */
void __VERIFIER_assert(int cond) {}
int N;
int main()
{
	N = unknown();
	if(N <= 0) return 1;
	//@ assert (N <= 2147483647/4);
	long long i;
	long long *a = malloc(sizeof(long long)*N);
	long long *b = malloc(sizeof(long long)*N);
	//@ admit \valid(a+(0 .. N-1));
	//@ admit \valid(b+(0 .. N-1));
	//@ admit \separated(a+(0 .. N-1), b+(0 .. N-1));
	for(i=0; i<N; i++)
	{
		if(i==0) {
			b[0] = 1;
		} else {
			b[i] = b[i-1] + 2;
		}
	}
	for(i=0; i<N; i++)
	{
		if(i==0) {
			a[0] = N + 1;
		} else {
			a[i] = a[i-1] + b[i-1] + 2;
		}
	}
	for(i=0; i<N; i++)
	{
		__VERIFIER_assert(a[i] == N + (i+1)*(i+1));
	}
	return 1;
}
