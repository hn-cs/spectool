#include<limits.h>
/*@
assigns \nothing;
ensures INT_MIN <= \result <= INT_MAX/4;
*/
int unknown();
#include<stdlib.h>
int N;
int main()
{
	N = unknown();
	if(N <= 0) return 1;
	//@ assert (N <= 2147483647/4);
	long long i;
	long long *a = malloc(sizeof(long long)*N);
	long long *b = malloc(sizeof(long long)*N);
	long long *c = malloc(sizeof(long long)*N);
	a[0] = 6;
	b[0] = 1;
	c[0] = 0;
		//@ admit \valid(a+(0 .. N-1));
		//@ admit \valid(b+(0 .. N-1));
		//@ admit \valid(c+(0 .. N-1));
		//@ admit \separated(a+(0 .. N-1), b+(0 .. N-1), c+(0 .. N-1));
	for(i=1; i<N; i++)
	{
		a[i] = a[i-1] + 6;
	}
	for(i=1; i<N; i++)
	{
		b[i] = b[i-1] + a[i-1];
	}
	for(i=1; i<N; i++)
	{
		c[i] = c[i-1] + b[i-1];
	}
	for(i=0; i<N; i++)
	{
		//@ assert(c[i] == i*i*i);
	}
	return 1;
}
